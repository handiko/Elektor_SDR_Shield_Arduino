﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.SerialPort1 = New System.IO.Ports.SerialPort(Me.components)
        Me.freqTextBox = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.setButton = New System.Windows.Forms.Button()
        Me.portComboBox = New System.Windows.Forms.ComboBox()
        Me.connectButton = New System.Windows.Forms.Button()
        Me.freqHScrollBar = New System.Windows.Forms.HScrollBar()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.WarningLabel = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.h10mRadioButton = New System.Windows.Forms.RadioButton()
        Me.h12mRadioButton = New System.Windows.Forms.RadioButton()
        Me.h15mRadioButton = New System.Windows.Forms.RadioButton()
        Me.h17mRadioButton = New System.Windows.Forms.RadioButton()
        Me.h20mRadioButton = New System.Windows.Forms.RadioButton()
        Me.h30mRadioButton = New System.Windows.Forms.RadioButton()
        Me.h40mRadioButton = New System.Windows.Forms.RadioButton()
        Me.h60mRadioButton = New System.Windows.Forms.RadioButton()
        Me.h80mRadioButton = New System.Windows.Forms.RadioButton()
        Me.h160mRadioButton = New System.Windows.Forms.RadioButton()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.B75mRadioButton = New System.Windows.Forms.RadioButton()
        Me.B49mRadioButton = New System.Windows.Forms.RadioButton()
        Me.B41mRadioButton = New System.Windows.Forms.RadioButton()
        Me.B31mRadioButton = New System.Windows.Forms.RadioButton()
        Me.B25RadioButton = New System.Windows.Forms.RadioButton()
        Me.B22mRadioButton = New System.Windows.Forms.RadioButton()
        Me.B19mRadioButton = New System.Windows.Forms.RadioButton()
        Me.B16mRadioButton = New System.Windows.Forms.RadioButton()
        Me.B15mRadioButton1 = New System.Windows.Forms.RadioButton()
        Me.LWMWRadioButton = New System.Windows.Forms.RadioButton()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.ifHScrollBar = New System.Windows.Forms.HScrollBar()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.ExitButton = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'freqTextBox
        '
        Me.freqTextBox.Location = New System.Drawing.Point(132, 98)
        Me.freqTextBox.Name = "freqTextBox"
        Me.freqTextBox.Size = New System.Drawing.Size(100, 20)
        Me.freqTextBox.TabIndex = 0
        Me.freqTextBox.Text = "5000"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(69, 101)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(57, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Frequency"
        '
        'setButton
        '
        Me.setButton.Location = New System.Drawing.Point(270, 96)
        Me.setButton.Name = "setButton"
        Me.setButton.Size = New System.Drawing.Size(75, 23)
        Me.setButton.TabIndex = 2
        Me.setButton.Text = "Set"
        Me.setButton.UseVisualStyleBackColor = True
        '
        'portComboBox
        '
        Me.portComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.portComboBox.FormattingEnabled = True
        Me.portComboBox.Location = New System.Drawing.Point(29, 13)
        Me.portComboBox.Name = "portComboBox"
        Me.portComboBox.Size = New System.Drawing.Size(121, 21)
        Me.portComboBox.Sorted = True
        Me.portComboBox.TabIndex = 23
        '
        'connectButton
        '
        Me.connectButton.Location = New System.Drawing.Point(53, 40)
        Me.connectButton.Name = "connectButton"
        Me.connectButton.Size = New System.Drawing.Size(73, 20)
        Me.connectButton.TabIndex = 24
        Me.connectButton.Text = "Open COM"
        Me.connectButton.UseVisualStyleBackColor = True
        '
        'freqHScrollBar
        '
        Me.freqHScrollBar.LargeChange = 5
        Me.freqHScrollBar.Location = New System.Drawing.Point(97, 36)
        Me.freqHScrollBar.Maximum = 6000
        Me.freqHScrollBar.Minimum = 17
        Me.freqHScrollBar.Name = "freqHScrollBar"
        Me.freqHScrollBar.Size = New System.Drawing.Size(415, 17)
        Me.freqHScrollBar.TabIndex = 25
        Me.freqHScrollBar.Value = 17
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(47, 40)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(47, 13)
        Me.Label2.TabIndex = 26
        Me.Label2.Text = "151 kHz"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(515, 40)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(44, 13)
        Me.Label3.TabIndex = 27
        Me.Label3.Text = "30 MHz"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(238, 101)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(26, 13)
        Me.Label4.TabIndex = 28
        Me.Label4.Text = "kHz"
        '
        'WarningLabel
        '
        Me.WarningLabel.AutoSize = True
        Me.WarningLabel.Location = New System.Drawing.Point(25, 72)
        Me.WarningLabel.Name = "WarningLabel"
        Me.WarningLabel.Size = New System.Drawing.Size(129, 13)
        Me.WarningLabel.TabIndex = 29
        Me.WarningLabel.Text = "Connect to COM port first!"
        Me.WarningLabel.Visible = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.h10mRadioButton)
        Me.Panel1.Controls.Add(Me.h12mRadioButton)
        Me.Panel1.Controls.Add(Me.h15mRadioButton)
        Me.Panel1.Controls.Add(Me.h17mRadioButton)
        Me.Panel1.Controls.Add(Me.h20mRadioButton)
        Me.Panel1.Controls.Add(Me.h30mRadioButton)
        Me.Panel1.Controls.Add(Me.h40mRadioButton)
        Me.Panel1.Controls.Add(Me.h60mRadioButton)
        Me.Panel1.Controls.Add(Me.h80mRadioButton)
        Me.Panel1.Controls.Add(Me.h160mRadioButton)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.B75mRadioButton)
        Me.Panel1.Controls.Add(Me.B49mRadioButton)
        Me.Panel1.Controls.Add(Me.B41mRadioButton)
        Me.Panel1.Controls.Add(Me.B31mRadioButton)
        Me.Panel1.Controls.Add(Me.B25RadioButton)
        Me.Panel1.Controls.Add(Me.B22mRadioButton)
        Me.Panel1.Controls.Add(Me.B19mRadioButton)
        Me.Panel1.Controls.Add(Me.B16mRadioButton)
        Me.Panel1.Controls.Add(Me.B15mRadioButton1)
        Me.Panel1.Controls.Add(Me.LWMWRadioButton)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Location = New System.Drawing.Point(38, 126)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(386, 219)
        Me.Panel1.TabIndex = 30
        '
        'h10mRadioButton
        '
        Me.h10mRadioButton.Location = New System.Drawing.Point(312, 175)
        Me.h10mRadioButton.Name = "h10mRadioButton"
        Me.h10mRadioButton.Size = New System.Drawing.Size(67, 17)
        Me.h10mRadioButton.TabIndex = 55
        Me.h10mRadioButton.TabStop = True
        Me.h10mRadioButton.Text = "10m"
        Me.h10mRadioButton.UseVisualStyleBackColor = True
        '
        'h12mRadioButton
        '
        Me.h12mRadioButton.Location = New System.Drawing.Point(239, 175)
        Me.h12mRadioButton.Name = "h12mRadioButton"
        Me.h12mRadioButton.Size = New System.Drawing.Size(67, 17)
        Me.h12mRadioButton.TabIndex = 54
        Me.h12mRadioButton.TabStop = True
        Me.h12mRadioButton.Text = "12m"
        Me.h12mRadioButton.UseVisualStyleBackColor = True
        '
        'h15mRadioButton
        '
        Me.h15mRadioButton.Location = New System.Drawing.Point(167, 175)
        Me.h15mRadioButton.Name = "h15mRadioButton"
        Me.h15mRadioButton.Size = New System.Drawing.Size(67, 17)
        Me.h15mRadioButton.TabIndex = 53
        Me.h15mRadioButton.TabStop = True
        Me.h15mRadioButton.Text = "15m"
        Me.h15mRadioButton.UseVisualStyleBackColor = True
        '
        'h17mRadioButton
        '
        Me.h17mRadioButton.Location = New System.Drawing.Point(92, 175)
        Me.h17mRadioButton.Name = "h17mRadioButton"
        Me.h17mRadioButton.Size = New System.Drawing.Size(67, 17)
        Me.h17mRadioButton.TabIndex = 52
        Me.h17mRadioButton.TabStop = True
        Me.h17mRadioButton.Text = "17m"
        Me.h17mRadioButton.UseVisualStyleBackColor = True
        '
        'h20mRadioButton
        '
        Me.h20mRadioButton.Location = New System.Drawing.Point(19, 175)
        Me.h20mRadioButton.Name = "h20mRadioButton"
        Me.h20mRadioButton.Size = New System.Drawing.Size(67, 17)
        Me.h20mRadioButton.TabIndex = 51
        Me.h20mRadioButton.TabStop = True
        Me.h20mRadioButton.Text = "20m"
        Me.h20mRadioButton.UseVisualStyleBackColor = True
        '
        'h30mRadioButton
        '
        Me.h30mRadioButton.Location = New System.Drawing.Point(312, 143)
        Me.h30mRadioButton.Name = "h30mRadioButton"
        Me.h30mRadioButton.Size = New System.Drawing.Size(67, 17)
        Me.h30mRadioButton.TabIndex = 50
        Me.h30mRadioButton.TabStop = True
        Me.h30mRadioButton.Text = "30m"
        Me.h30mRadioButton.UseVisualStyleBackColor = True
        '
        'h40mRadioButton
        '
        Me.h40mRadioButton.Location = New System.Drawing.Point(239, 143)
        Me.h40mRadioButton.Name = "h40mRadioButton"
        Me.h40mRadioButton.Size = New System.Drawing.Size(67, 17)
        Me.h40mRadioButton.TabIndex = 49
        Me.h40mRadioButton.TabStop = True
        Me.h40mRadioButton.Text = "40m"
        Me.h40mRadioButton.UseVisualStyleBackColor = True
        '
        'h60mRadioButton
        '
        Me.h60mRadioButton.Location = New System.Drawing.Point(167, 143)
        Me.h60mRadioButton.Name = "h60mRadioButton"
        Me.h60mRadioButton.Size = New System.Drawing.Size(67, 17)
        Me.h60mRadioButton.TabIndex = 48
        Me.h60mRadioButton.TabStop = True
        Me.h60mRadioButton.Text = "60m"
        Me.h60mRadioButton.UseVisualStyleBackColor = True
        '
        'h80mRadioButton
        '
        Me.h80mRadioButton.Location = New System.Drawing.Point(90, 143)
        Me.h80mRadioButton.Name = "h80mRadioButton"
        Me.h80mRadioButton.Size = New System.Drawing.Size(67, 17)
        Me.h80mRadioButton.TabIndex = 47
        Me.h80mRadioButton.TabStop = True
        Me.h80mRadioButton.Text = "80m"
        Me.h80mRadioButton.UseVisualStyleBackColor = True
        '
        'h160mRadioButton
        '
        Me.h160mRadioButton.Location = New System.Drawing.Point(19, 143)
        Me.h160mRadioButton.Name = "h160mRadioButton"
        Me.h160mRadioButton.Size = New System.Drawing.Size(67, 17)
        Me.h160mRadioButton.TabIndex = 46
        Me.h160mRadioButton.TabStop = True
        Me.h160mRadioButton.Text = "160m"
        Me.h160mRadioButton.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(11, 116)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(60, 13)
        Me.Label8.TabIndex = 36
        Me.Label8.Text = "Ham Radio"
        '
        'B75mRadioButton
        '
        Me.B75mRadioButton.Location = New System.Drawing.Point(90, 34)
        Me.B75mRadioButton.Name = "B75mRadioButton"
        Me.B75mRadioButton.Size = New System.Drawing.Size(67, 17)
        Me.B75mRadioButton.TabIndex = 45
        Me.B75mRadioButton.TabStop = True
        Me.B75mRadioButton.Text = "75m"
        Me.B75mRadioButton.UseVisualStyleBackColor = True
        '
        'B49mRadioButton
        '
        Me.B49mRadioButton.Location = New System.Drawing.Point(165, 34)
        Me.B49mRadioButton.Name = "B49mRadioButton"
        Me.B49mRadioButton.Size = New System.Drawing.Size(67, 17)
        Me.B49mRadioButton.TabIndex = 44
        Me.B49mRadioButton.TabStop = True
        Me.B49mRadioButton.Text = "49m"
        Me.B49mRadioButton.UseVisualStyleBackColor = True
        '
        'B41mRadioButton
        '
        Me.B41mRadioButton.Location = New System.Drawing.Point(238, 34)
        Me.B41mRadioButton.Name = "B41mRadioButton"
        Me.B41mRadioButton.Size = New System.Drawing.Size(67, 17)
        Me.B41mRadioButton.TabIndex = 43
        Me.B41mRadioButton.TabStop = True
        Me.B41mRadioButton.Text = "41m"
        Me.B41mRadioButton.UseVisualStyleBackColor = True
        '
        'B31mRadioButton
        '
        Me.B31mRadioButton.Location = New System.Drawing.Point(311, 34)
        Me.B31mRadioButton.Name = "B31mRadioButton"
        Me.B31mRadioButton.Size = New System.Drawing.Size(67, 17)
        Me.B31mRadioButton.TabIndex = 42
        Me.B31mRadioButton.TabStop = True
        Me.B31mRadioButton.Text = "31m"
        Me.B31mRadioButton.UseVisualStyleBackColor = True
        '
        'B25RadioButton
        '
        Me.B25RadioButton.Location = New System.Drawing.Point(19, 73)
        Me.B25RadioButton.Name = "B25RadioButton"
        Me.B25RadioButton.Size = New System.Drawing.Size(67, 17)
        Me.B25RadioButton.TabIndex = 41
        Me.B25RadioButton.TabStop = True
        Me.B25RadioButton.Text = "25m"
        Me.B25RadioButton.UseVisualStyleBackColor = True
        '
        'B22mRadioButton
        '
        Me.B22mRadioButton.Location = New System.Drawing.Point(90, 73)
        Me.B22mRadioButton.Name = "B22mRadioButton"
        Me.B22mRadioButton.Size = New System.Drawing.Size(67, 17)
        Me.B22mRadioButton.TabIndex = 40
        Me.B22mRadioButton.TabStop = True
        Me.B22mRadioButton.Text = "22m"
        Me.B22mRadioButton.UseVisualStyleBackColor = True
        '
        'B19mRadioButton
        '
        Me.B19mRadioButton.Location = New System.Drawing.Point(165, 71)
        Me.B19mRadioButton.Name = "B19mRadioButton"
        Me.B19mRadioButton.Size = New System.Drawing.Size(67, 17)
        Me.B19mRadioButton.TabIndex = 39
        Me.B19mRadioButton.TabStop = True
        Me.B19mRadioButton.Text = "19m"
        Me.B19mRadioButton.UseVisualStyleBackColor = True
        '
        'B16mRadioButton
        '
        Me.B16mRadioButton.Location = New System.Drawing.Point(239, 69)
        Me.B16mRadioButton.Name = "B16mRadioButton"
        Me.B16mRadioButton.Size = New System.Drawing.Size(67, 17)
        Me.B16mRadioButton.TabIndex = 38
        Me.B16mRadioButton.TabStop = True
        Me.B16mRadioButton.Text = "16m"
        Me.B16mRadioButton.UseVisualStyleBackColor = True
        '
        'B15mRadioButton1
        '
        Me.B15mRadioButton1.Location = New System.Drawing.Point(312, 69)
        Me.B15mRadioButton1.Name = "B15mRadioButton1"
        Me.B15mRadioButton1.Size = New System.Drawing.Size(67, 17)
        Me.B15mRadioButton1.TabIndex = 37
        Me.B15mRadioButton1.TabStop = True
        Me.B15mRadioButton1.Text = "15m"
        Me.B15mRadioButton1.UseVisualStyleBackColor = True
        '
        'LWMWRadioButton
        '
        Me.LWMWRadioButton.Location = New System.Drawing.Point(19, 34)
        Me.LWMWRadioButton.Name = "LWMWRadioButton"
        Me.LWMWRadioButton.Size = New System.Drawing.Size(67, 17)
        Me.LWMWRadioButton.TabIndex = 36
        Me.LWMWRadioButton.TabStop = True
        Me.LWMWRadioButton.Text = "LW/MW"
        Me.LWMWRadioButton.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(11, 8)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(55, 13)
        Me.Label7.TabIndex = 35
        Me.Label7.Text = "Broadcast"
        '
        'ifHScrollBar
        '
        Me.ifHScrollBar.LargeChange = 1
        Me.ifHScrollBar.Location = New System.Drawing.Point(206, 65)
        Me.ifHScrollBar.Maximum = 20
        Me.ifHScrollBar.Minimum = 5
        Me.ifHScrollBar.Name = "ifHScrollBar"
        Me.ifHScrollBar.Size = New System.Drawing.Size(218, 17)
        Me.ifHScrollBar.TabIndex = 31
        Me.ifHScrollBar.Value = 12
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(187, 69)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(16, 13)
        Me.Label5.TabIndex = 32
        Me.Label5.Text = "IF"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(427, 69)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(19, 13)
        Me.Label6.TabIndex = 33
        Me.Label6.Text = "12"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Panel2.Controls.Add(Me.portComboBox)
        Me.Panel2.Controls.Add(Me.connectButton)
        Me.Panel2.Controls.Add(Me.WarningLabel)
        Me.Panel2.Location = New System.Drawing.Point(440, 126)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(178, 100)
        Me.Panel2.TabIndex = 34
        '
        'ExitButton
        '
        Me.ExitButton.Location = New System.Drawing.Point(543, 322)
        Me.ExitButton.Name = "ExitButton"
        Me.ExitButton.Size = New System.Drawing.Size(75, 23)
        Me.ExitButton.TabIndex = 30
        Me.ExitButton.Text = "Exit"
        Me.ExitButton.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Silver
        Me.ClientSize = New System.Drawing.Size(652, 399)
        Me.Controls.Add(Me.ExitButton)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.ifHScrollBar)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.freqHScrollBar)
        Me.Controls.Add(Me.setButton)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.freqTextBox)
        Me.Name = "Form1"
        Me.Text = "SDR Arduino Shield Tuning"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents SerialPort1 As IO.Ports.SerialPort
    Friend WithEvents freqTextBox As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents setButton As Button
    Friend WithEvents connectButton As Button
    Friend WithEvents freqHScrollBar As HScrollBar
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents portComboBox As ComboBox
    Friend WithEvents WarningLabel As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents ifHScrollBar As HScrollBar
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents LWMWRadioButton As RadioButton
    Friend WithEvents B15mRadioButton1 As RadioButton
    Friend WithEvents B16mRadioButton As RadioButton
    Friend WithEvents B22mRadioButton As RadioButton
    Friend WithEvents B19mRadioButton As RadioButton
    Friend WithEvents B75mRadioButton As RadioButton
    Friend WithEvents B49mRadioButton As RadioButton
    Friend WithEvents B41mRadioButton As RadioButton
    Friend WithEvents B31mRadioButton As RadioButton
    Friend WithEvents B25RadioButton As RadioButton
    Friend WithEvents h30mRadioButton As RadioButton
    Friend WithEvents h40mRadioButton As RadioButton
    Friend WithEvents h60mRadioButton As RadioButton
    Friend WithEvents h80mRadioButton As RadioButton
    Friend WithEvents h160mRadioButton As RadioButton
    Friend WithEvents h10mRadioButton As RadioButton
    Friend WithEvents h12mRadioButton As RadioButton
    Friend WithEvents h15mRadioButton As RadioButton
    Friend WithEvents h17mRadioButton As RadioButton
    Friend WithEvents h20mRadioButton As RadioButton
    Friend WithEvents Panel2 As Panel
    Friend WithEvents ExitButton As Button
End Class
