﻿Imports System
Imports System.Threading
Imports System.IO.Ports
Imports System.ComponentModel

Public Class Form1
    Dim myPort As Array
    Dim Freq As Integer



    Private Sub setButton_Click(sender As Object, e As EventArgs) Handles setButton.Click
        Freq = Int(Val(freqTextBox.Text) / 5)
        freqHScrollBar.Value = Freq

    End Sub


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Panel1.Visible = False
        WarningLabel.Visible = True
        setButton.Enabled = False


        myPort = IO.Ports.SerialPort.GetPortNames()
        portComboBox.Items.AddRange(myPort)
        If portComboBox.Items.Count > 0 Then
            portComboBox.SelectedIndex = 0
        Else
            MessageBox.Show("No COM port found", "SDR radio tuning", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Application.Exit()


        End If
    End Sub

    Private Sub connectButton_Click(sender As Object, e As EventArgs) Handles connectButton.Click
        If connectButton.Text = "Open COM" Then
            SerialPort1.PortName = portComboBox.Text
            SerialPort1.Open()
            SerialPort1.RtsEnable = True
            System.Threading.Thread.Sleep(1000)
            SerialPort1.DtrEnable = True
            System.Threading.Thread.Sleep(1000)
            SerialPort1.DtrEnable = False
            System.Threading.Thread.Sleep(1000)
            SerialPort1.RtsEnable = False
            connectButton.Text = "Close COM"
            WarningLabel.Visible = False
            Panel1.Visible = True

            setButton.Enabled = True
        Else
            SerialPort1.Close()
            WarningLabel.Visible = True
            connectButton.Text = "Open COM"
            Panel1.Visible = False

            setButton.Enabled = False
        End If
        My.Application.DoEvents()
    End Sub

    Private Sub freqHScrollBar_ValueChanged(sender As Object, e As EventArgs) Handles freqHScrollBar.ValueChanged
        Dim n, f, iff, vfo As Integer
        Dim text As String
        n = freqHScrollBar.Value
        iff = ifHScrollBar.Value
        If n > 179 Then f = n * 5
        If n < 180 Then f = n * 9
        freqTextBox.Text = f
        Debug.Print(f)
        vfo = f - iff + 12 '(f+12)*4
        text = Str(vfo)
        For n = 1 To Len(text)
            SerialPort1.Write(Mid(text, n, 1))
        Next
        SerialPort1.Write(vbCrLf)
        My.Application.DoEvents()
    End Sub

    Private Sub ifHScrollBar_Scroll(sender As Object, e As ScrollEventArgs) Handles ifHScrollBar.Scroll
        Dim n, f, iff, vfo As Integer
        Dim text As String
        n = freqHScrollBar.Value
        iff = ifHScrollBar.Value
        If n > 179 Then f = n * 5
        If n < 180 Then f = n * 9
        freqTextBox.Text = f
        Label6.Text = Str(iff)
        vfo = f - iff + 12 '(f+12)*4
        text = Str(vfo)
        For n = 1 To Len(text)
            SerialPort1.Write(Mid(text, n, 1))
        Next
        SerialPort1.Write(vbCr)
        SerialPort1.Write(vbLf)
        'My.Application.DoEvents()
    End Sub

    Private Sub Form1_Closed(sender As Object, e As EventArgs) Handles Me.Closed
        SerialPort1.Close()
    End Sub

    Private Sub LWMWRadioButton_Click_1(sender As Object, e As EventArgs) Handles LWMWRadioButton.Click
        Freq = 531
        freqHScrollBar.Value = Freq / 9
    End Sub

    Private Sub B15mRadioButton1_Click(sender As Object, e As EventArgs) Handles B15mRadioButton1.Click
        Freq = 18900
        freqHScrollBar.Value = Freq / 5
    End Sub

    Private Sub B16mRadioButton_Click(sender As Object, e As EventArgs) Handles B16mRadioButton.Click
        Freq = 17480
        freqHScrollBar.Value = Freq / 5
    End Sub

    Private Sub B22mRadioButton_Click(sender As Object, e As EventArgs) Handles B22mRadioButton.Click
        Freq = 13570
        freqHScrollBar.Value = Freq / 5
    End Sub

    Private Sub B19mRadioButton_Click(sender As Object, e As EventArgs) Handles B19mRadioButton.Click
        Freq = 15100
        freqHScrollBar.Value = Freq / 5
    End Sub

    Private Sub B25RadioButton_Click(sender As Object, e As EventArgs) Handles B25RadioButton.Click
        Freq = 11600
        freqHScrollBar.Value = Freq / 5
    End Sub

    Private Sub B31mRadioButton_Click(sender As Object, e As EventArgs) Handles B31mRadioButton.Click
        Freq = 9400
        freqHScrollBar.Value = Freq / 5
    End Sub

    Private Sub B41mRadioButton_Click(sender As Object, e As EventArgs) Handles B41mRadioButton.Click
        Freq = 7200
        freqHScrollBar.Value = Freq / 5
    End Sub

    Private Sub B49mRadioButton_Click(sender As Object, e As EventArgs) Handles B49mRadioButton.Click
        Freq = 5900
        freqHScrollBar.Value = Freq / 5
    End Sub

    Private Sub B75mRadioButton_Click(sender As Object, e As EventArgs) Handles B75mRadioButton.Click
        Freq = 3900
        freqHScrollBar.Value = Freq / 5
    End Sub

    Private Sub h160mRadioButton_Click(sender As Object, e As EventArgs) Handles h160mRadioButton.Click
        Freq = 1810
        freqHScrollBar.Value = Freq / 5
    End Sub

    Private Sub h80mRadioButton_Click(sender As Object, e As EventArgs) Handles h80mRadioButton.Click
        Freq = 3500
        freqHScrollBar.Value = Freq / 5
    End Sub

    Private Sub h60mRadioButton_Click(sender As Object, e As EventArgs) Handles h60mRadioButton.Click
        Freq = 5000
        freqHScrollBar.Value = Freq / 5
    End Sub

    Private Sub h40mRadioButton_Click(sender As Object, e As EventArgs) Handles h40mRadioButton.Click
        Freq = 7000
        freqHScrollBar.Value = Freq / 5
    End Sub

    Private Sub h30mRadioButton_Click(sender As Object, e As EventArgs) Handles h30mRadioButton.Click
        Freq = 10100
        freqHScrollBar.Value = Freq / 5
    End Sub

    Private Sub h20mRadioButton_Click(sender As Object, e As EventArgs) Handles h20mRadioButton.Click
        Freq = 14000
        freqHScrollBar.Value = Freq / 5
    End Sub

    Private Sub h17mRadioButton_Click(sender As Object, e As EventArgs) Handles h17mRadioButton.Click
        Freq = 18060
        freqHScrollBar.Value = Freq / 5
    End Sub

    Private Sub h15mRadioButton_Click(sender As Object, e As EventArgs) Handles h15mRadioButton.Click
        Freq = 21000
        freqHScrollBar.Value = Freq / 5
    End Sub

    Private Sub h12mRadioButton_Click(sender As Object, e As EventArgs) Handles h12mRadioButton.Click
        Freq = 24900
        freqHScrollBar.Value = Freq / 5
    End Sub

    Private Sub h10mRadioButton_Click(sender As Object, e As EventArgs) Handles h10mRadioButton.Click
        Freq = 28000
        freqHScrollBar.Value = Freq / 5
    End Sub

    Private Sub ExitButton_Click(sender As Object, e As EventArgs) Handles ExitButton.Click
        SerialPort1.Close()
        Application.Exit()
    End Sub
End Class
